/////////////// WEB PORTFOLIO DESIGN ///////////////

Creating my web portfolio I used my XD file created for User Experience Design course as the mockup and used the skills we learned in the Responsive Web Design II class. As my skills have evolved since I created the mockup their are a couple changes from the mockup and the final design.

I used basic html files for each page and css with the addition of some animation to make the site more lively. The animation is on the social links wshen you hover and on the send button on the contact form. To create the different layouts for sizes I used the @media screen with the different sizes in pixels.

A couple challenges I faced were the resizing of the photos and their placement. Since they were different sizes in the moblie layout compared to the desktop layout. The hardest one was on the about me page. Turning the photo of my face from a long rectangle to the square with the text besides. Also I had to figure out how to move the photos down slightly since I made them show the middle.

What I learned while creating my portfolio is that recreating something 100% is quite hard. Getting everything to fully work, be responsive and change properly between all the different sizes was also a challeneg because sometimes things for overlap so I had to go back and change things for it all to work.



/////////////// ANY ASSESTS OR RESOURCES ///////////////

I used https://css-tricks.com/ to remind myslef of a lot of the techniques for the grid and the flexbox layouts.

I used https://fonts.google.com/ and the font Roboto for my website.

All the images used in the portofilo are photos that I took and own.

I used the <iframe> tag to put a google map to show the location. 